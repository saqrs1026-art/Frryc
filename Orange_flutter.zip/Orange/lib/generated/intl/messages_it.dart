// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a it locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'it';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
    "aResetPasswordLinkHasBeenSentToYourEmail":
        MessageLookupByLibrary.simpleMessage(
          "Un link per reimpostare la password è stato inviato alla tua email. Usalo per reimpostare la password.",
        ),
    "aVerificationLinkHasBeenSentToYourEmailPlease":
        MessageLookupByLibrary.simpleMessage(
          "Un link di verifica è stato inviato alla tua email. Verifica il link per accedere.",
        ),
    "about": MessageLookupByLibrary.simpleMessage("Di"),
    "accept": MessageLookupByLibrary.simpleMessage("Accettare"),
    "accountDetails": MessageLookupByLibrary.simpleMessage("DETTAGLI ACCOUNT"),
    "adFreeExperience": MessageLookupByLibrary.simpleMessage(
      "Esperienza senza pubblicità",
    ),
    "add": MessageLookupByLibrary.simpleMessage("AGGIUNGERE"),
    "addCoins": MessageLookupByLibrary.simpleMessage("AGGIUNGI MONETE"),
    "addComment": MessageLookupByLibrary.simpleMessage("Aggiungi un commento"),
    "addPhotos": MessageLookupByLibrary.simpleMessage("Aggiungi foto"),
    "addYourProfilePhotos": MessageLookupByLibrary.simpleMessage(
      "Aggiungi le foto del tuo profilo 📸",
    ),
    "afterDeletingTheChatYouCanNotRestoreOurMessage":
        MessageLookupByLibrary.simpleMessage(
          "Dopo aver eliminato la chat, non è possibile ripristinare il nostro messaggio. Il messaggio verrà eliminato dal tuo account.",
        ),
    "age": MessageLookupByLibrary.simpleMessage("ETÀ"),
    "agePref": MessageLookupByLibrary.simpleMessage("Preferenza di età"),
    "agreeNContinue": MessageLookupByLibrary.simpleMessage(
      "Accetta e continua",
    ),
    "allow": MessageLookupByLibrary.simpleMessage("Permettere"),
    "allowLocationAccess": MessageLookupByLibrary.simpleMessage(
      "Consenti accesso alla posizione",
    ),
    "allowOrangeToAccessYourLocationToFindMatchesNearby":
        MessageLookupByLibrary.simpleMessage(
          "Consenti a @appname di accedere alla tua posizione per trovare corrispondenze nelle vicinanze e migliorare la tua esperienza di incontri.",
        ),
    "allowPermission": MessageLookupByLibrary.simpleMessage(
      "Consenti permesso",
    ),
    "amount": MessageLookupByLibrary.simpleMessage("Importo pagato:"),
    "and": MessageLookupByLibrary.simpleMessage("E"),
    "annual": MessageLookupByLibrary.simpleMessage("Annuale"),
    "annually": MessageLookupByLibrary.simpleMessage("Annualmente"),
    "anonymous": MessageLookupByLibrary.simpleMessage("Vai anonimo"),
    "anonymousData": MessageLookupByLibrary.simpleMessage(
      "Attiva, se non vuoi essere visto da nessuna parte nell\'app. Come: Cerca, Pila di carte.",
    ),
    "appLanguages": MessageLookupByLibrary.simpleMessage("Lingue dell\'app"),
    "application": MessageLookupByLibrary.simpleMessage("  APPLICAZIONE"),
    "apply": MessageLookupByLibrary.simpleMessage("FARE DOMANDA A"),
    "areYou": MessageLookupByLibrary.simpleMessage("Sei"),
    "areYouSure": MessageLookupByLibrary.simpleMessage("Sei sicuro"),
    "areYouSureYouEtc": MessageLookupByLibrary.simpleMessage(
      "Sei sicuro di voler eliminare questo messaggio?",
    ),
    "areYouSureYouWantToDeleteTheComment": MessageLookupByLibrary.simpleMessage(
      "Sei sicuro di voler eliminare il commento?",
    ),
    "areYouSureYouWantToDeleteThePost": MessageLookupByLibrary.simpleMessage(
      "Sei sicuro di voler eliminare il post?",
    ),
    "areYouSureYouWantToDislikeThisUser": MessageLookupByLibrary.simpleMessage(
      "Sei sicuro di voler non gradire questo utente?",
    ),
    "areYouSureYouWantToEnd": MessageLookupByLibrary.simpleMessage(
      "Sei sicuro di voler terminare il tuo video in diretta?",
    ),
    "areYouSureYouWantToShowThisProfileAgain":
        MessageLookupByLibrary.simpleMessage(
          "Sei sicuro di voler mostrare di nuovo questo profilo?",
        ),
    "areYouSureYouWantToUnblockThisUser": MessageLookupByLibrary.simpleMessage(
      "Sei sicuro di voler sbloccare questo utente?",
    ),
    "artist": MessageLookupByLibrary.simpleMessage("Artista"),
    "attach": MessageLookupByLibrary.simpleMessage("Allegare"),
    "automatically": MessageLookupByLibrary.simpleMessage("automaticamente"),
    "bankTransfer": MessageLookupByLibrary.simpleMessage(
      "Trasferimento bancario",
    ),
    "bayContinuingThePurchaseEtc": MessageLookupByLibrary.simpleMessage(
      "Continuando l\'acquisto accetti la ns",
    ),
    "bio": MessageLookupByLibrary.simpleMessage("BIOLOGICO"),
    "block": MessageLookupByLibrary.simpleMessage("Bloccare"),
    "blockedProfiles": MessageLookupByLibrary.simpleMessage("Profili bloccati"),
    "both": MessageLookupByLibrary.simpleMessage("ENTRAMBI"),
    "boys": MessageLookupByLibrary.simpleMessage("RAGAZZI"),
    "cancel": MessageLookupByLibrary.simpleMessage("Annulla"),
    "cancelCap": MessageLookupByLibrary.simpleMessage("ANNULLA"),
    "change": MessageLookupByLibrary.simpleMessage("Modifica"),
    "chatHint": MessageLookupByLibrary.simpleMessage("Scrivi qualcosa...!"),
    "chatWith": MessageLookupByLibrary.simpleMessage("CHATTARE CON"),
    "checkOutThisProfile": MessageLookupByLibrary.simpleMessage(
      "Dai un\'occhiata a questo profilo",
    ),
    "chef": MessageLookupByLibrary.simpleMessage("Cuoco"),
    "city": MessageLookupByLibrary.simpleMessage("Città"),
    "close": MessageLookupByLibrary.simpleMessage("Vicino"),
    "coinsPerMinutesPleaseConfirmIfYouToContinueOr":
        MessageLookupByLibrary.simpleMessage(
          "monete al minuto, si prega di confermare se continuare o meno",
        ),
    "coinsPerMsgPleaseConfirmIfYouToContinueOr":
        MessageLookupByLibrary.simpleMessage(
          "monete per Msg, Si prega di confermare se continuare o meno",
        ),
    "coinsPleaseConfirmIfYouToContinueOrNot":
        MessageLookupByLibrary.simpleMessage(
          "monete, si prega di confermare se continuare o meno",
        ),
    "collected": MessageLookupByLibrary.simpleMessage("Raccolto"),
    "comment": MessageLookupByLibrary.simpleMessage("Commento..."),
    "commentDelete": MessageLookupByLibrary.simpleMessage(
      "Eliminare il commento?",
    ),
    "commentNotFound": MessageLookupByLibrary.simpleMessage(
      "Commento non trovato",
    ),
    "comments": MessageLookupByLibrary.simpleMessage("Commenti"),
    "complete": MessageLookupByLibrary.simpleMessage("Completare"),
    "confirmPassword": MessageLookupByLibrary.simpleMessage(
      "Conferma password",
    ),
    "continueCap": MessageLookupByLibrary.simpleMessage("CONTINUA"),
    "continuePlease": MessageLookupByLibrary.simpleMessage(
      "  continua per favore",
    ),
    "continueText": MessageLookupByLibrary.simpleMessage("Continua"),
    "continueWithApple": MessageLookupByLibrary.simpleMessage(
      "Continua con Apple",
    ),
    "continueWithFacebook": MessageLookupByLibrary.simpleMessage(
      "Continua con Facebook",
    ),
    "continueWithGoogle": MessageLookupByLibrary.simpleMessage(
      "Continua con Google",
    ),
    "couldNotLaunch": MessageLookupByLibrary.simpleMessage(
      "Impossibile avviare",
    ),
    "country": MessageLookupByLibrary.simpleMessage("Paese"),
    "createPost": MessageLookupByLibrary.simpleMessage("Crea messaggio"),
    "cyberbullying": MessageLookupByLibrary.simpleMessage("Cyber ​​bullismo"),
    "dashboard": MessageLookupByLibrary.simpleMessage(
      "  PANNELLO DI CONTROLLO",
    ),
    "day": MessageLookupByLibrary.simpleMessage("Giorno"),
    "days": MessageLookupByLibrary.simpleMessage("Giorni"),
    "delete": MessageLookupByLibrary.simpleMessage("Eliminare"),
    "deleteAccount": MessageLookupByLibrary.simpleMessage(
      "Eliminare l\'account",
    ),
    "deleteCap": MessageLookupByLibrary.simpleMessage("ELIMINARE"),
    "deleteChat": MessageLookupByLibrary.simpleMessage("Elimina chat"),
    "deleteDialogDis": MessageLookupByLibrary.simpleMessage(
      "Vuoi davvero eliminare il tuo account? Non sarai in grado di recuperarlo in seguito e i dati andranno persi per sempre",
    ),
    "deleteMessage": MessageLookupByLibrary.simpleMessage(
      "Cancella il messaggio",
    ),
    "deletePost": MessageLookupByLibrary.simpleMessage("Elimina messaggio"),
    "deleteThisChat": MessageLookupByLibrary.simpleMessage(
      "Elimina questa chat",
    ),
    "deleteThisStory": MessageLookupByLibrary.simpleMessage(
      "Eliminare questa storia?",
    ),
    "diamond": MessageLookupByLibrary.simpleMessage("  Diamanti raccolti:"),
    "diamond1": MessageLookupByLibrary.simpleMessage("Diamanti:"),
    "diamondCap": MessageLookupByLibrary.simpleMessage("DIAMANTE"),
    "diamonds": MessageLookupByLibrary.simpleMessage("DIAMANTI"),
    "diamondsCamel": MessageLookupByLibrary.simpleMessage("Diamanti"),
    "discoverLikemindedPeople": MessageLookupByLibrary.simpleMessage(
      "Scopri persone affini 🤗",
    ),
    "distancePreference": MessageLookupByLibrary.simpleMessage(
      "Preferenza di distanza",
    ),
    "doYouReallyWantToDeleteThisChatYouWont": MessageLookupByLibrary.simpleMessage(
      "Vuoi davvero eliminare questa chat? Dopo non sarai in grado di recuperare alcun tipo di dato. Spero che tu ne sia consapevole!",
    ),
    "doYouReallyWantToHideThisProfileOnceHidden":
        MessageLookupByLibrary.simpleMessage(
          "Vuoi davvero nascondere questo profilo? Una volta nascosto, non apparirà più in Esplora, Ricerca o nel tuo Feed.",
        ),
    "doYouReallyWantToLive": MessageLookupByLibrary.simpleMessage(
      "Vuoi davvero vivere. Si prega di continuare a trasmettere in diretta",
    ),
    "doYouWantToDeleteThisStoryYouCanNot": MessageLookupByLibrary.simpleMessage(
      "Vuoi eliminare questa storia? Non puoi ripristinare la storia, verrà eliminata definitivamente.",
    ),
    "docType": MessageLookupByLibrary.simpleMessage("TIPO DI DOCUMENTO"),
    "donTHaveAnAccount": MessageLookupByLibrary.simpleMessage(
      "Non hai un account?",
    ),
    "dontShowThisProfileAgain": MessageLookupByLibrary.simpleMessage(
      "Non mostrare più questo profilo",
    ),
    "drivingLicence": MessageLookupByLibrary.simpleMessage("Patente di guida"),
    "edit": MessageLookupByLibrary.simpleMessage("MODIFICARE"),
    "editProfile": MessageLookupByLibrary.simpleMessage("MODIFICA PROFILO"),
    "eligibility": MessageLookupByLibrary.simpleMessage(
      "Idoneità al live streaming",
    ),
    "eligible": MessageLookupByLibrary.simpleMessage("IDONEO"),
    "email": MessageLookupByLibrary.simpleMessage("E-mail"),
    "emailSentSuccessfully": MessageLookupByLibrary.simpleMessage(
      "Email inviata correttamente...",
    ),
    "empty": MessageLookupByLibrary.simpleMessage("VUOTO"),
    "end": MessageLookupByLibrary.simpleMessage("FINE"),
    "enterAbout": MessageLookupByLibrary.simpleMessage("Inserisci CHI SIAMO"),
    "enterAccountDetails": MessageLookupByLibrary.simpleMessage(
      "Inserisci i dettagli dell\'account",
    ),
    "enterAddress": MessageLookupByLibrary.simpleMessage("Città, Paese"),
    "enterAge": MessageLookupByLibrary.simpleMessage("Inserisci ETÀ"),
    "enterBio": MessageLookupByLibrary.simpleMessage("Entra in BIO"),
    "enterConfirmPassword": MessageLookupByLibrary.simpleMessage(
      "Immettere Conferma password",
    ),
    "enterEmail": MessageLookupByLibrary.simpleMessage("Inserisci l\'e-mail"),
    "enterFullName": MessageLookupByLibrary.simpleMessage(
      "Inserisci il nome completo",
    ),
    "enterFullReason": MessageLookupByLibrary.simpleMessage(
      "Immettere il motivo completo",
    ),
    "enterPassword": MessageLookupByLibrary.simpleMessage(
      "Inserisci la password",
    ),
    "enterThePasswordForTheAccountNwithTheEmailBelow":
        MessageLookupByLibrary.simpleMessage(
          "Inserisci la password per l\'account \ncon l\'e-mail qui sotto",
        ),
    "enterUsername": MessageLookupByLibrary.simpleMessage("Inserire username"),
    "enterYourMailOnWhichYouHaveNcreatedAnAccount":
        MessageLookupByLibrary.simpleMessage(
          "Inserisci la tua posta su cui hai\ncreato un account. Invieremo un collegamento\nper reimpostare la tua password",
        ),
    "exit": MessageLookupByLibrary.simpleMessage("Uscita"),
    "explainMore": MessageLookupByLibrary.simpleMessage("Spiega meglio"),
    "explore": MessageLookupByLibrary.simpleMessage("Esplorare"),
    "exploreProfiles": MessageLookupByLibrary.simpleMessage(
      "Esplora i profili",
    ),
    "facebook": MessageLookupByLibrary.simpleMessage("FACEBOOK"),
    "failedPayment": MessageLookupByLibrary.simpleMessage("Pagamento fallito"),
    "failedToLoadVideo": MessageLookupByLibrary.simpleMessage(
      "Impossibile caricare il video: Impossibile aprire",
    ),
    "feed": MessageLookupByLibrary.simpleMessage("Foraggio"),
    "female": MessageLookupByLibrary.simpleMessage("Femmina"),
    "filter": MessageLookupByLibrary.simpleMessage("Filtro"),
    "find": MessageLookupByLibrary.simpleMessage("Trova"),
    "findMatch": MessageLookupByLibrary.simpleMessage("Trova corrispondenza"),
    "findReligion": MessageLookupByLibrary.simpleMessage("Trova religione 🙏"),
    "findSomeone": MessageLookupByLibrary.simpleMessage("Trova qualcuno"),
    "findSomeoneRandomly": MessageLookupByLibrary.simpleMessage(
      "Trova qualcuno a caso\nE controlla il suo profilo",
    ),
    "findSomeoneWhoTrulyUnderstandsYou": MessageLookupByLibrary.simpleMessage(
      "Trova qualcuno che ti capisca davvero.",
    ),
    "fitness": MessageLookupByLibrary.simpleMessage("Fitness"),
    "follow": MessageLookupByLibrary.simpleMessage("Seguire"),
    "followerList": MessageLookupByLibrary.simpleMessage("Elenco dei follower"),
    "followers": MessageLookupByLibrary.simpleMessage("Seguaci"),
    "following": MessageLookupByLibrary.simpleMessage("Seguente"),
    "followingList": MessageLookupByLibrary.simpleMessage("Elenco seguente"),
    "foodies": MessageLookupByLibrary.simpleMessage("Buongustai"),
    "forgotPassword": MessageLookupByLibrary.simpleMessage(
      "Ha dimenticato la password?",
    ),
    "forgotYourPassword": MessageLookupByLibrary.simpleMessage(
      "Hai dimenticato la password ?",
    ),
    "freeChat": MessageLookupByLibrary.simpleMessage("Chat gratuita"),
    "freeLive": MessageLookupByLibrary.simpleMessage("Live gratuito"),
    "freeTrialDescription": MessageLookupByLibrary.simpleMessage(
      "@count @get_period prova gratuita",
    ),
    "fullName": MessageLookupByLibrary.simpleMessage("Nome e cognome"),
    "fullNameCap": MessageLookupByLibrary.simpleMessage("NOME E COGNOME"),
    "gender": MessageLookupByLibrary.simpleMessage("GENERE"),
    "genderPref": MessageLookupByLibrary.simpleMessage("Preferenza di genere"),
    "getAccess": MessageLookupByLibrary.simpleMessage(
      "OTTIENI L\'ACCESSO A GIVE LIVE",
    ),
    "getStarted1Subtitle": MessageLookupByLibrary.simpleMessage(
      "Trova: Chiama: Chatta: Streaming",
    ),
    "getStarted2Subtitle": MessageLookupByLibrary.simpleMessage(
      "Crea il tuo profilo in base a \ndiversi interessi e trova \npersone che la pensano allo stesso modo",
    ),
    "getStarted3Subtitle": MessageLookupByLibrary.simpleMessage(
      "Consenti l\'accesso per ottenere la tua posizione \ne trovare persone locali nelle vicinanze \ne entrare in contatto con loro.",
    ),
    "getStarted4Subtitle": MessageLookupByLibrary.simpleMessage(
      "Trasmetti te stesso in streaming e condividi \nla tua vita e unisciti ad altri streamer,\n commenta e invia regali",
    ),
    "getUnlimitedReverseSwipe": MessageLookupByLibrary.simpleMessage(
      "Ottieni swipe inversi illimitati",
    ),
    "getVerifiedBadge": MessageLookupByLibrary.simpleMessage(
      "Ottieni badge verificato",
    ),
    "girls": MessageLookupByLibrary.simpleMessage("RAGAZZE"),
    "giveItATry": MessageLookupByLibrary.simpleMessage("Provalo"),
    "go": MessageLookupByLibrary.simpleMessage("Andare"),
    "goLive": MessageLookupByLibrary.simpleMessage("ANDARE IN DIRETTA"),
    "goToProfile": MessageLookupByLibrary.simpleMessage("Vai al profilo"),
    "harassment": MessageLookupByLibrary.simpleMessage("Molestie"),
    "hasCommentedOnYourPost": MessageLookupByLibrary.simpleMessage(
      "ha commentato il tuo post",
    ),
    "hasFollowedYourProfile": MessageLookupByLibrary.simpleMessage(
      "ha seguito il tuo profilo.",
    ),
    "hasLikedYourPost": MessageLookupByLibrary.simpleMessage(
      "ha messo mi piace al tuo post",
    ),
    "hasLikedYourProfile": MessageLookupByLibrary.simpleMessage(
      "ha messo mi piace al tuo profilo.",
    ),
    "hasLikedYourProfileYouShouldCheckTheirProfile":
        MessageLookupByLibrary.simpleMessage(
          "  ha apprezzato il tuo profilo, dovresti controllare il suo profilo!",
        ),
    "hiddenProfile": MessageLookupByLibrary.simpleMessage("Profilo nascosto"),
    "hiddenProfiles": MessageLookupByLibrary.simpleMessage("Profili nascosti"),
    "hide": MessageLookupByLibrary.simpleMessage("Nascondere"),
    "hideInfo": MessageLookupByLibrary.simpleMessage("NASCONDI INFORMAZIONI"),
    "history": MessageLookupByLibrary.simpleMessage("  STORIA"),
    "hurryUpAndJoinBeforeItEnds": MessageLookupByLibrary.simpleMessage(
      "Affrettati a unirti prima che finisca.",
    ),
    "iAgreeTo": MessageLookupByLibrary.simpleMessage("Sono d\'accordo"),
    "iWillDoItLater": MessageLookupByLibrary.simpleMessage("Lo farò più tardi"),
    "idCard": MessageLookupByLibrary.simpleMessage(
      "Carta di identità nazionale",
    ),
    "ifAppearsThatCameraPermissionHasNotBeenGrantedTo":
        MessageLookupByLibrary.simpleMessage(
          "Se appare che l\'autorizzazione alla fotocamera non è stata concessa. Per l\'App dovrai consentire l\'accesso alla fotocamera dalle impostazioni.",
        ),
        "ifYouCloseTheSheetYourMessageCoinWillBe": MessageLookupByLibrary.simpleMessage(
          "Se chiudi il pannello, il tuo messaggio coin andrà perso.",
        ),
        "image": MessageLookupByLibrary.simpleMessage("IMMAGINE"),
    "imageIsEmpty": MessageLookupByLibrary.simpleMessage("L\'immagine è vuota"),
    "inappropriateContent": MessageLookupByLibrary.simpleMessage(
      "Contenuto inappropriato",
    ),
    "incorrectPasswordOrUserid": MessageLookupByLibrary.simpleMessage(
      "Password o ID utente errato",
    ),
    "incorrectPasswordProvidedForThisUser":
        MessageLookupByLibrary.simpleMessage(
          "Password errata fornita per questo utente.",
        ),
    "instagram": MessageLookupByLibrary.simpleMessage("INSTAGRAM"),
    "interest": MessageLookupByLibrary.simpleMessage("Interesse"),
    "intro": MessageLookupByLibrary.simpleMessage(
      "BREVE VIDEO DI INTRODUZIONE",
    ),
    "itLooksLikeEtc": MessageLookupByLibrary.simpleMessage(
      "Sembra che il tuo portafoglio non abbia monete sufficienti per questa azione. ricarichiamolo per godere di questa funzione.",
    ),
    "itsAMatch": MessageLookupByLibrary.simpleMessage("È una corrispondenza!"),
    "join": MessageLookupByLibrary.simpleMessage("GIUNTURA"),
    "joinLive": MessageLookupByLibrary.simpleMessage("Vite"),
    "km": MessageLookupByLibrary.simpleMessage("km"),
    "kmsAway": MessageLookupByLibrary.simpleMessage("km di distanza"),
    "language": MessageLookupByLibrary.simpleMessage("Lingua"),
    "languages": MessageLookupByLibrary.simpleMessage("Le lingue"),
    "languagesDetail": MessageLookupByLibrary.simpleMessage(
      "Lingue che parlerai durante lo streaming..",
    ),
    "languagesIKnow": MessageLookupByLibrary.simpleMessage(
      "Lingue che conosco",
    ),
    "languagesYouEtc": MessageLookupByLibrary.simpleMessage("LINGUE CHE PARLI"),
    "large": MessageLookupByLibrary.simpleMessage("Grande"),
    "legal": MessageLookupByLibrary.simpleMessage("LEGALE"),
    "letYourPhotosTellYourStory": MessageLookupByLibrary.simpleMessage(
      "Lascia che le tue foto raccontino la tua storia.",
    ),
    "lifetime": MessageLookupByLibrary.simpleMessage("A vita"),
    "likeProfiles": MessageLookupByLibrary.simpleMessage("Come Profili"),
    "live": MessageLookupByLibrary.simpleMessage("Vivere"),
    "liveCAp": MessageLookupByLibrary.simpleMessage("Vivere"),
    "liveCap": MessageLookupByLibrary.simpleMessage("VIVERE"),
    "liveStreamCap": MessageLookupByLibrary.simpleMessage(
      "TRASMISSIONE IN DIRETTA",
    ),
    "liveStreamEnded": MessageLookupByLibrary.simpleMessage(
      "Streaming in diretta terminato",
    ),
    "liveStreamPriceWillCostYou": MessageLookupByLibrary.simpleMessage(
      "Il prezzo del live streaming ti costerà",
    ),
    "liveVerification": MessageLookupByLibrary.simpleMessage(
      "VERIFICA IN DIRETTA",
    ),
    "lives": MessageLookupByLibrary.simpleMessage("Vite"),
    "livestream": MessageLookupByLibrary.simpleMessage(
      "Portafoglio / Dashboard Livestream",
    ),
    "logIn": MessageLookupByLibrary.simpleMessage("LOGIN"),
    "logOut": MessageLookupByLibrary.simpleMessage("Disconnettersi"),
    "logOutDis": MessageLookupByLibrary.simpleMessage(
      "Vuoi davvero uscire da questa app?",
    ),
    "loginToContinue": MessageLookupByLibrary.simpleMessage(
      "ACCEDI PER CONTINUARE",
    ),
    "look": MessageLookupByLibrary.simpleMessage("Aspetto"),
    "makeYourPreferenceWider": MessageLookupByLibrary.simpleMessage(
      "Amplia le tue preferenze",
    ),
    "male": MessageLookupByLibrary.simpleMessage("Maschio"),
    "map": MessageLookupByLibrary.simpleMessage("Carta geografica"),
    "match": MessageLookupByLibrary.simpleMessage("Corrispondenza"),
    "matchPreference": MessageLookupByLibrary.simpleMessage(
      "Preferenza di corrispondenza",
    ),
    "member": MessageLookupByLibrary.simpleMessage("Membro"),
    "message": MessageLookupByLibrary.simpleMessage("Messaggio"),
    "messagePriceWillCostYou": MessageLookupByLibrary.simpleMessage(
      "Il prezzo del messaggio ti costerà",
    ),
    "messageWillOnlyBeRemoved": MessageLookupByLibrary.simpleMessage(
      "Il messaggio verrà rimosso solo da questo dispositivo Sei sicuro?",
    ),
    "month": MessageLookupByLibrary.simpleMessage("Mese"),
    "monthly": MessageLookupByLibrary.simpleMessage("Mensile"),
    "months": MessageLookupByLibrary.simpleMessage("Mesi"),
    "moreInfo": MessageLookupByLibrary.simpleMessage("ULTERIORI INFORMAZIONI"),
    "movies": MessageLookupByLibrary.simpleMessage("Film"),
    "music": MessageLookupByLibrary.simpleMessage("Musica"),
    "nearbyProfileOnMap": MessageLookupByLibrary.simpleMessage(
      "Profili nelle vicinanze sulla mappa",
    ),
    "next": MessageLookupByLibrary.simpleMessage("PROSSIMO"),
    "nextProfile": MessageLookupByLibrary.simpleMessage("Profilo successivo"),
    "no": MessageLookupByLibrary.simpleMessage("NO"),
    "noComment": MessageLookupByLibrary.simpleMessage("No comment"),
    "noData": MessageLookupByLibrary.simpleMessage("Nessun dato"),
    "noDataAvailable": MessageLookupByLibrary.simpleMessage(
      "Nessun dato disponibile",
    ),
    "noLikeData": MessageLookupByLibrary.simpleMessage("Dati non simili"),
    "noLocation": MessageLookupByLibrary.simpleMessage("Nessuna posizione"),
    "noMatchesFound": MessageLookupByLibrary.simpleMessage(
      "Nessuna corrispondenza trovata.",
    ),
    "noMoreProfileMatchesFound": MessageLookupByLibrary.simpleMessage(
      "Nessun altro profilo corrispondente trovato",
    ),
    "noRedeemData": MessageLookupByLibrary.simpleMessage(
      "Nessun dato di riscatto",
    ),
    "noSavedData": MessageLookupByLibrary.simpleMessage("Nessun dato salvato"),
    "noThanks": MessageLookupByLibrary.simpleMessage("No, grazie"),
    "noUserFoundWithThatEmailPleaseRegisterWithThis":
        MessageLookupByLibrary.simpleMessage(
          "Nessun utente trovato con questa email. Si prega di registrarsi con questa email.",
        ),
    "noUsersAreLive": MessageLookupByLibrary.simpleMessage(
      "Nessun utente è attivo",
    ),
    "notEligible": MessageLookupByLibrary.simpleMessage("NON AMMISSIBILE"),
    "notification": MessageLookupByLibrary.simpleMessage("NOTIFICHE"),
    "notificationData": MessageLookupByLibrary.simpleMessage(
      "Tienilo acceso, se vuoi ricevere le notifiche",
    ),
    "nowCap": MessageLookupByLibrary.simpleMessage("ORA"),
    "ok": MessageLookupByLibrary.simpleMessage("OK"),
    "openSettings": MessageLookupByLibrary.simpleMessage("Apri Impostazioni"),
    "optional": MessageLookupByLibrary.simpleMessage("Opzionale"),
    "options": MessageLookupByLibrary.simpleMessage("OPZIONI"),
    "or": MessageLookupByLibrary.simpleMessage("O"),
    "other": MessageLookupByLibrary.simpleMessage("Altro"),
    "password": MessageLookupByLibrary.simpleMessage("Parola d\'ordine"),
    "passwordMismatch": MessageLookupByLibrary.simpleMessage(
      "Mancata corrispondenza della password",
    ),
    "paymentGateway": MessageLookupByLibrary.simpleMessage("CASELLO STRADALE"),
    "paypal": MessageLookupByLibrary.simpleMessage("PayPal"),
    "pending": MessageLookupByLibrary.simpleMessage("IN ATTESA DI"),
    "personal": MessageLookupByLibrary.simpleMessage("Personale"),
    "personalHarassment": MessageLookupByLibrary.simpleMessage(
      "Molestie personali",
    ),
    "photo": MessageLookupByLibrary.simpleMessage("Foto"),
    "photos": MessageLookupByLibrary.simpleMessage("Fotografie"),
    "photosCap": MessageLookupByLibrary.simpleMessage("FOTOGRAFIE"),
    "platform": MessageLookupByLibrary.simpleMessage("piattaforma"),
    "pleaseAddAtLeastEtc": MessageLookupByLibrary.simpleMessage(
      "Aggiungi almeno 1 immagine",
    ),
    "pleaseAddAtLeastInterest": MessageLookupByLibrary.simpleMessage(
      "Aggiungi almeno 1 interesse",
    ),
    "pleaseAddInterestsInTheAdminPanelToContinue":
        MessageLookupByLibrary.simpleMessage(
          "Aggiungi gli interessi nel pannello di amministrazione per continuare a completare il tuo profilo.",
        ),
    "pleaseAddLanguagesInTheAdminPanelToContinue":
        MessageLookupByLibrary.simpleMessage(
          "Aggiungi le lingue nel pannello di amministrazione per continuare a completare il tuo profilo.",
        ),
    "pleaseAddRelationshipGoalsInTheAdminPanelToContinue":
        MessageLookupByLibrary.simpleMessage(
          "Aggiungi gli obiettivi di relazione nel pannello di amministrazione per continuare a completare il tuo profilo.",
        ),
    "pleaseAddReligionInTheAdminPanelToContinue":
        MessageLookupByLibrary.simpleMessage(
          "Aggiungi la religione nel pannello di amministrazione per continuare a completare il tuo profilo.",
        ),
    "pleaseAddSelfiePhoto": MessageLookupByLibrary.simpleMessage(
      "Si prega di aggiungere una foto selfie",
    ),
    "pleaseAddSocialLinks": MessageLookupByLibrary.simpleMessage(
      "Si prega di aggiungere collegamenti sociali",
    ),
    "pleaseApplyForLiveStreamFromLivestreamDashboardFromProfile":
        MessageLookupByLibrary.simpleMessage(
          "Fai domanda per il live streaming dalla dashboard livestream dal profilo!",
        ),
    "pleaseCheckTerm": MessageLookupByLibrary.simpleMessage(
      "Si prega di controllare Termini e condizioni",
    ),
    "pleaseEnterEmail": MessageLookupByLibrary.simpleMessage(
      "Per favore inserisci l\'e-mail...!",
    ),
    "pleaseEnterValidEmailAddress": MessageLookupByLibrary.simpleMessage(
      "Inserisci indirizzo email valido",
    ),
    "pleaseEnterYourAge": MessageLookupByLibrary.simpleMessage(
      "Per favore inserisci la tua età",
    ),
    "pleaseEnterYourName": MessageLookupByLibrary.simpleMessage(
      "Inserisci il tuo nome.",
    ),
    "pleaseSelectCity": MessageLookupByLibrary.simpleMessage("Seleziona città"),
    "pleaseSelectCountry": MessageLookupByLibrary.simpleMessage(
      "Seleziona paese",
    ),
    "pleaseSelectDocumentFile": MessageLookupByLibrary.simpleMessage(
      "Seleziona il file del documento.",
    ),
    "pleaseSelectImage": MessageLookupByLibrary.simpleMessage(
      "Si prega di selezionare l\'immagine",
    ),
    "pleaseSelectState": MessageLookupByLibrary.simpleMessage(
      "Seleziona stato/regione",
    ),
    "pleaseSelectYourInterestsOrSkipThisStep":
        MessageLookupByLibrary.simpleMessage(
          "Seleziona i tuoi interessi o salta questo passaggio.",
        ),
    "pleaseValidEmail": MessageLookupByLibrary.simpleMessage(
      "Si prega di e-mail valida",
    ),
    "pleaseVerifyYourEmailFromYourInbox": MessageLookupByLibrary.simpleMessage(
      "Verifica la tua e-mail dalla tua casella di posta",
    ),
    "policy1": MessageLookupByLibrary.simpleMessage(
      "Selezionando Accetto e continua di seguito, \n accetto",
    ),
    "policy2": MessageLookupByLibrary.simpleMessage("Termini di utilizzo"),
    "policy3": MessageLookupByLibrary.simpleMessage("  E"),
    "policy4": MessageLookupByLibrary.simpleMessage(
      "politica sulla riservatezza",
    ),
    "post": MessageLookupByLibrary.simpleMessage("Inviare"),
        "postCreatedSuccessfully": MessageLookupByLibrary.simpleMessage(
          "Post creato con successo",
        ),
        "posts": MessageLookupByLibrary.simpleMessage("Messaggi"),
    "preferences": MessageLookupByLibrary.simpleMessage("Preferenze"),
    "premium": MessageLookupByLibrary.simpleMessage("Premium"),
    "previous": MessageLookupByLibrary.simpleMessage("Precedente"),
    "priceCap": MessageLookupByLibrary.simpleMessage("PREZZO"),
    "privacy": MessageLookupByLibrary.simpleMessage(
      "IMPOSTAZIONI DELLA PRIVACY",
    ),
    "privacyPolicy": MessageLookupByLibrary.simpleMessage(
      "politica sulla riservatezza",
    ),
    "pro": MessageLookupByLibrary.simpleMessage("PRO"),
    "processing": MessageLookupByLibrary.simpleMessage("in lavorazione"),
    "profile": MessageLookupByLibrary.simpleMessage("Profilo"),
    "profileCap": MessageLookupByLibrary.simpleMessage("PROFILO"),
    "pushNotification": MessageLookupByLibrary.simpleMessage(
      "Le notifiche push",
    ),
    "randomScreen": MessageLookupByLibrary.simpleMessage("Schermata casuale"),
    "randoms": MessageLookupByLibrary.simpleMessage("Casuali"),
    "readLess": MessageLookupByLibrary.simpleMessage("Leggi di meno..."),
    "readMore": MessageLookupByLibrary.simpleMessage("Per saperne di più..."),
    "redeem": MessageLookupByLibrary.simpleMessage("RISCATTARE"),
    "redeemCap": MessageLookupByLibrary.simpleMessage("RISCATTARE"),
    "redeemRequests": MessageLookupByLibrary.simpleMessage(
      "RICHIESTE DI RISCATTO",
    ),
    "register": MessageLookupByLibrary.simpleMessage("REGISTRATI"),
    "registerInfoText": MessageLookupByLibrary.simpleMessage(
      "Sembra che tu non abbia un account. \nCreiamo un nuovo account",
    ),
    "registrationSuccessfully": MessageLookupByLibrary.simpleMessage(
      "Registrazione effettuata con successo",
    ),
    "relationshipGoals": MessageLookupByLibrary.simpleMessage(
      "Obiettivi di relazione 👩‍❤️‍👨",
    ),
    "religion": MessageLookupByLibrary.simpleMessage("Religione"),
    "report": MessageLookupByLibrary.simpleMessage("Rapporto"),
    "reportCap": MessageLookupByLibrary.simpleMessage("RAPPORTO"),
    "reportPost": MessageLookupByLibrary.simpleMessage("Segnala il messaggio"),
    "reportUser": MessageLookupByLibrary.simpleMessage("SEGNALA UTENTE"),
    "reportedSubmitted": MessageLookupByLibrary.simpleMessage(
      "Segnalato Inviato",
    ),
    "reportedSuccessfully": MessageLookupByLibrary.simpleMessage(
      "Segnalato con successo!!",
    ),
    "reqVerification": MessageLookupByLibrary.simpleMessage(
      "RICHIESTA VERIFICA",
    ),
    "requests": MessageLookupByLibrary.simpleMessage("  RICHIESTE"),
    "reset": MessageLookupByLibrary.simpleMessage("Ripristina"),
    "restore": MessageLookupByLibrary.simpleMessage("Ripristina"),
    "reverse": MessageLookupByLibrary.simpleMessage("INVERSIONE"),
    "reverseSwipeWillCostYou": MessageLookupByLibrary.simpleMessage(
      "Reverse Swipe ti costerà",
    ),
    "save": MessageLookupByLibrary.simpleMessage("SALVA"),
    "savedProfiles": MessageLookupByLibrary.simpleMessage("Profili salvati"),
    "searchHere": MessageLookupByLibrary.simpleMessage("Cerca qui"),
    "searchProfile": MessageLookupByLibrary.simpleMessage("Cerca profilo"),
    "searching": MessageLookupByLibrary.simpleMessage("Ricerca..."),
    "selectAnother": MessageLookupByLibrary.simpleMessage("Seleziona un altro"),
    "selectDocument": MessageLookupByLibrary.simpleMessage(
      "Seleziona Documento",
    ),
    "selectInterestsToContinue": MessageLookupByLibrary.simpleMessage(
      "Seleziona gli interessi per continuare",
    ),
    "selectLanguages": MessageLookupByLibrary.simpleMessage(
      "Seleziona lingue 🌍",
    ),
    "selectReason": MessageLookupByLibrary.simpleMessage("Seleziona Motivo"),
    "selectYourLanguage": MessageLookupByLibrary.simpleMessage(
      "Seleziona la tua lingua",
    ),
    "selectYourRelationshipGoal": MessageLookupByLibrary.simpleMessage(
      "Seleziona il tuo obiettivo di relazione",
    ),
    "selectYourReligion": MessageLookupByLibrary.simpleMessage(
      "Seleziona la tua religione",
    ),
    "selected": MessageLookupByLibrary.simpleMessage("Selezionato"),
    "semiAnnually": MessageLookupByLibrary.simpleMessage("Semestrale"),
    "send": MessageLookupByLibrary.simpleMessage("Inviare"),
    "sendMedia": MessageLookupByLibrary.simpleMessage(
      "Invia contenuti multimediali",
    ),
    "share": MessageLookupByLibrary.simpleMessage("CONDIVIDERE"),
    "shop": MessageLookupByLibrary.simpleMessage("NEGOZIO"),
    "shortIntro": MessageLookupByLibrary.simpleMessage(
      "Breve intro su di te..",
    ),
    "show": MessageLookupByLibrary.simpleMessage("Visualizza"),
    "signUp": MessageLookupByLibrary.simpleMessage("Iscrizione"),
    "singing": MessageLookupByLibrary.simpleMessage("Cantando"),
    "sixMonth": MessageLookupByLibrary.simpleMessage("6 mesi"),
    "skip": MessageLookupByLibrary.simpleMessage("Saltare"),
    "social": MessageLookupByLibrary.simpleMessage("LINK PROFILO SOCIAL"),
    "socialData": MessageLookupByLibrary.simpleMessage(
      "Link ad alcuni dei tuoi profili sui social media, che ci aiutano a saperne di più sui tuoi follower da parte dei fan.",
    ),
    "socialLinks": MessageLookupByLibrary.simpleMessage("Link social"),
    "something": MessageLookupByLibrary.simpleMessage("QUALCOSA SU DI TE?"),
    "startFinding": MessageLookupByLibrary.simpleMessage("Inizia a cercare"),
    "startMatching": MessageLookupByLibrary.simpleMessage("INIZIA AD ABBINARE"),
    "startingProfileInfoText": MessageLookupByLibrary.simpleMessage(
      "Crea il tuo profilo con fantastiche foto, bio di interessi e distinguiti dagli altri!",
    ),
    "state": MessageLookupByLibrary.simpleMessage("Stato/Regione"),
    "streamCap": MessageLookupByLibrary.simpleMessage("FLUSSO"),
    "streamFor": MessageLookupByLibrary.simpleMessage("Flusso per"),
    "streamYourself": MessageLookupByLibrary.simpleMessage(
      "Trasmetti te stesso",
    ),
    "streamed": MessageLookupByLibrary.simpleMessage("  In streaming per:"),
    "submit": MessageLookupByLibrary.simpleMessage("INVIA"),
    "subscribe": MessageLookupByLibrary.simpleMessage("Abbonati"),
    "subscribeNow": MessageLookupByLibrary.simpleMessage("Abbonati ora"),
    "subscribeToProEtc": MessageLookupByLibrary.simpleMessage(
      "Iscriviti a PRO - Non avere limiti",
    ),
    "subscriptionDescription": MessageLookupByLibrary.simpleMessage(
      "@price / mese. Fatturato @unit_label",
    ),
    "sure": MessageLookupByLibrary.simpleMessage("  Sicuro?"),
    "swipe": MessageLookupByLibrary.simpleMessage("Scorri"),
    "swipeRight": MessageLookupByLibrary.simpleMessage("SCORRI A DESTRA"),
    "swipeRightToViewTheNextProfile": MessageLookupByLibrary.simpleMessage(
      "Scorri verso destra per visualizzare il profilo successivo.",
    ),
    "switchMap": MessageLookupByLibrary.simpleMessage("Mostrami sulla mappa"),
    "switchMapData": MessageLookupByLibrary.simpleMessage(
      "Tienilo acceso, se vuoi essere visto su Map",
    ),
    "takePhoto": MessageLookupByLibrary.simpleMessage("Fare foto"),
    "termAndCondition": MessageLookupByLibrary.simpleMessage(
      "  Termini & Condizioni,",
    ),
    "terms": MessageLookupByLibrary.simpleMessage("Termini"),
    "termsOfUse": MessageLookupByLibrary.simpleMessage("Termini di utilizzo"),
    "thatGreat": MessageLookupByLibrary.simpleMessage("È fantastico"),
    "theAccountAlreadyExistsForThatEmail": MessageLookupByLibrary.simpleMessage(
      "Esiste già un account con questa email.",
    ),
    "thePasswordProvidedIsTooWeak": MessageLookupByLibrary.simpleMessage(
      "La password fornita è troppo debole.",
    ),
    "theSubscriptionsRenewsAutomaticallyAsPerThePlanUnlessCancelled":
        MessageLookupByLibrary.simpleMessage(
          "L’abbonamento si rinnova automaticamente in base al piano, a meno che non venga annullato almeno 24 ore prima della fine del periodo corrente. Puoi gestire e annullare l’abbonamento in qualsiasi momento dalle impostazioni dell’App Store/Play Store.",
        ),
    "thisUserBlockYou": MessageLookupByLibrary.simpleMessage(
      "Questo utente ti blocca",
    ),
    "thisVideoIsGreaterThan50MbnpleaseSelectAnother":
        MessageLookupByLibrary.simpleMessage(
          "Questo video supera i 50 mb\nSelezionare un altro...",
        ),
    "threeMonth": MessageLookupByLibrary.simpleMessage("3 mesi"),
    "threeMonths": MessageLookupByLibrary.simpleMessage("Tre mesi"),
    "threshold": MessageLookupByLibrary.simpleMessage("Soglia minima :"),
    "time": MessageLookupByLibrary.simpleMessage("  Tempo:"),
    "toAccessYourCameraAndMicrophone": MessageLookupByLibrary.simpleMessage(
      "per accedere alla fotocamera e al microfono",
    ),
    "toContinueBelown": MessageLookupByLibrary.simpleMessage("Continuando,\n"),
    "toSeeNearbyProfilesWeNeedAccessToYourLocation":
        MessageLookupByLibrary.simpleMessage(
          "Per vedere i profili nelle vicinanze, dobbiamo avere accesso alla tua posizione. Senza di essa, non potrai vedere le persone vicino a te.",
        ),
    "toSendMessage": MessageLookupByLibrary.simpleMessage(
      "per inviare un messaggio.",
    ),
    "today": MessageLookupByLibrary.simpleMessage("Oggi"),
    "tooLarge": MessageLookupByLibrary.simpleMessage("Troppo grande"),
    "totalCollection": MessageLookupByLibrary.simpleMessage(
      "COLLEZIONE TOTALE",
    ),
    "totalStream": MessageLookupByLibrary.simpleMessage("FLUSSI TOTALI"),
    "travel": MessageLookupByLibrary.simpleMessage("Viaggio"),
    "tryExpandingYourAgeOrDistancePreferencesOrSwitchInterests":
        MessageLookupByLibrary.simpleMessage(
          "Prova ad ampliare le preferenze di età o distanza, o cambia interessi per scoprire più persone.",
        ),
    "twoMonth": MessageLookupByLibrary.simpleMessage("2 mesi"),
    "twoMonths": MessageLookupByLibrary.simpleMessage("Due mesi"),
    "unBlock": MessageLookupByLibrary.simpleMessage("Sbloccare"),
    "unblockCap": MessageLookupByLibrary.simpleMessage("SBLOCCARE"),
    "unfollow": MessageLookupByLibrary.simpleMessage("Smetti di seguire"),
    "unhide": MessageLookupByLibrary.simpleMessage("Mostra"),
    "upgradeExperience": MessageLookupByLibrary.simpleMessage(
      "Migliora esperienza",
    ),
    "upgradeFrom": MessageLookupByLibrary.simpleMessage("Aggiorna da"),
    "upgradeToEnjoyAllTheFeatures": MessageLookupByLibrary.simpleMessage(
      "Aggiorna per godere di tutte le funzionalità.",
    ),
    "useAutomaticallyEtc": MessageLookupByLibrary.simpleMessage(
      "utilizzare automaticamente dal prossimo",
    ),
    "userBlock": MessageLookupByLibrary.simpleMessage(
      "Sei stato bloccato dall\'amministratore.",
    ),
    "userDidNotAllowCamera": MessageLookupByLibrary.simpleMessage(
      "L\'utente non ha consentito la fotocamera",
    ),
    "userDidNotAllowCameraAndMicrophonePermission":
        MessageLookupByLibrary.simpleMessage(
          "L\'utente non ha consentito l\'autorizzazione alla fotocamera e al microfono.",
        ),
    "userNotFound": MessageLookupByLibrary.simpleMessage(
      "Utente non trovato!!",
    ),
    "userNotLive": MessageLookupByLibrary.simpleMessage(
      "Utente non in diretta",
    ),
    "username": MessageLookupByLibrary.simpleMessage("Nome utente"),
    "users": MessageLookupByLibrary.simpleMessage("Utenti"),
    "validEmail": MessageLookupByLibrary.simpleMessage(
      "Inserire un\'email valida",
    ),
    "verification": MessageLookupByLibrary.simpleMessage(
      "Richiedi la verifica",
    ),
    "verifiedAccountsHaveBlueEtc": MessageLookupByLibrary.simpleMessage(
      "Gli account verificati hanno segni di spunta blu accanto ai loro nomi per mostrare che abbiamo confermato che sono la presenza reale di personaggi pubblici o celebrità.",
    ),
        "versionText": MessageLookupByLibrary.simpleMessage("Versione"),
        "video": MessageLookupByLibrary.simpleMessage("Video?"),
        "videoCall": MessageLookupByLibrary.simpleMessage("Video chiamata"),
        "videoCap": MessageLookupByLibrary.simpleMessage("VIDEO"),
        "videoDurationIs": MessageLookupByLibrary.simpleMessage(
      "La durata del video è",
    ),
    "videoPreview": MessageLookupByLibrary.simpleMessage(
      "Schermata di anteprima video",
    ),
    "videos": MessageLookupByLibrary.simpleMessage("Video"),
    "view": MessageLookupByLibrary.simpleMessage("Visualizzazione"),
    "viewers": MessageLookupByLibrary.simpleMessage("Spettatori"),
    "walking": MessageLookupByLibrary.simpleMessage("A piedi"),
    "wallet": MessageLookupByLibrary.simpleMessage("PORTAFOGLIO DIAMANTI"),
    "walletCap": MessageLookupByLibrary.simpleMessage("PORTAFOGLIO"),
    "week": MessageLookupByLibrary.simpleMessage("Settimana"),
    "weekly": MessageLookupByLibrary.simpleMessage("Settimanale"),
    "weeks": MessageLookupByLibrary.simpleMessage("Settimane"),
    "whatDoYouWantToSelect": MessageLookupByLibrary.simpleMessage(
      "Cosa vuoi selezionare?",
    ),
    "whereDoYouLive": MessageLookupByLibrary.simpleMessage("DOVE VIVI ?"),
    "whichItemWouldYouLikeEtc": MessageLookupByLibrary.simpleMessage(
      "Quale elemento desideri selezionare?\nSeleziona un elemento",
    ),
    "whoTrulyUnderstandsYou": MessageLookupByLibrary.simpleMessage(
      "che ti capiscano davvero.",
    ),
    "writeMessage": MessageLookupByLibrary.simpleMessage("Scrivi un messaggio"),
    "writeSomethingHere": MessageLookupByLibrary.simpleMessage(
      "Scrivi qualcosa qui...",
    ),
    "year": MessageLookupByLibrary.simpleMessage("Anno"),
    "years": MessageLookupByLibrary.simpleMessage("Anni"),
    "yes": MessageLookupByLibrary.simpleMessage("SÌ"),
    "yesterday": MessageLookupByLibrary.simpleMessage("Ieri"),
    "you": MessageLookupByLibrary.simpleMessage("Voi"),
    "youAre": MessageLookupByLibrary.simpleMessage("Sei"),
    "youAreFakeUser": MessageLookupByLibrary.simpleMessage(
      "Sei un utente falso",
    ),
    "youArePremiumMember": MessageLookupByLibrary.simpleMessage(
      "Sei un membro premium",
    ),
    "youAreReporting": MessageLookupByLibrary.simpleMessage(
      "Stai segnalando questo utente",
    ),
    "youBlockThisUser": MessageLookupByLibrary.simpleMessage(
      "Hai bloccato questo utente",
    ),
    "youMust18": MessageLookupByLibrary.simpleMessage(
      "Devi avere almeno 18 anni",
    ),
    "youMustBe18": MessageLookupByLibrary.simpleMessage(
      "Devi avere almeno 18 anni",
    ),
    "youWillBeSentEtc": MessageLookupByLibrary.simpleMessage(
      "VERRAI MANDATO FUORI PRESTO",
    ),
    "yourApplicationIsPendingPleaseWait": MessageLookupByLibrary.simpleMessage(
      "La tua domanda è in sospeso, attendi",
    ),
    "yourLiveStreamHasBeenEndednbelowIsASummaryOf":
        MessageLookupByLibrary.simpleMessage(
          "Il tuo live streaming è terminato!\nDi seguito è riportato un riepilogo.",
        ),
    "yourMatching": MessageLookupByLibrary.simpleMessage(
      "La tua corrispondenza",
    ),
    "yourMatchings": MessageLookupByLibrary.simpleMessage(
      "Le tue corrispondenze",
    ),
    "yourProfileIsReady": MessageLookupByLibrary.simpleMessage(
      "Il tuo profilo è pronto. 🎉",
    ),
    "yourSelfie": MessageLookupByLibrary.simpleMessage("IL TUO SELFIE"),
    "youtube": MessageLookupByLibrary.simpleMessage("YOUTUBE"),
  };
}
